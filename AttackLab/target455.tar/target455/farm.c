/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_418()
{
    return 2428993864U;
}

void setval_431(unsigned *p)
{
    *p = 2425393752U;
}

void setval_309(unsigned *p)
{
    *p = 3653458056U;
}

unsigned getval_498()
{
    return 3281025081U;
}

unsigned addval_251(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_236(unsigned x)
{
    return x + 3284633930U;
}

unsigned addval_276(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_159(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_176(unsigned x)
{
    return x + 3523794573U;
}

void setval_331(unsigned *p)
{
    *p = 3229925773U;
}

unsigned addval_407(unsigned x)
{
    return x + 2430642504U;
}

unsigned addval_430(unsigned x)
{
    return x + 3284240843U;
}

unsigned getval_486()
{
    return 3286272328U;
}

unsigned getval_219()
{
    return 3531921035U;
}

void setval_381(unsigned *p)
{
    *p = 3524840073U;
}

unsigned addval_355(unsigned x)
{
    return x + 3676881289U;
}

void setval_178(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_402()
{
    return 3767093462U;
}

void setval_291(unsigned *p)
{
    *p = 3375939979U;
}

unsigned getval_209()
{
    return 3281046153U;
}

unsigned getval_150()
{
    return 3281174921U;
}

unsigned getval_341()
{
    return 3380920712U;
}

void setval_120(unsigned *p)
{
    *p = 3682915849U;
}

void setval_323(unsigned *p)
{
    *p = 3281049225U;
}

unsigned addval_246(unsigned x)
{
    return x + 3224423049U;
}

unsigned getval_350()
{
    return 3224950413U;
}

unsigned addval_287(unsigned x)
{
    return x + 3536115337U;
}

void setval_161(unsigned *p)
{
    *p = 3677407881U;
}

unsigned getval_100()
{
    return 3677410953U;
}

unsigned getval_280()
{
    return 3524840073U;
}

unsigned getval_135()
{
    return 3767101695U;
}

void setval_111(unsigned *p)
{
    *p = 3353381192U;
}

void setval_312(unsigned *p)
{
    *p = 2445380065U;
}

unsigned getval_373()
{
    return 3376990857U;
}

unsigned addval_289(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_330()
{
    return 3221804681U;
}

unsigned getval_363()
{
    return 3286270280U;
}

unsigned addval_446(unsigned x)
{
    return x + 4291021441U;
}

unsigned getval_245()
{
    return 3398015463U;
}

unsigned getval_163()
{
    return 3284240723U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
